package com.example;

public class Course {
    private String name;
    private int number;
    private int numStudents;
    private int semester;
    private int creditHours;
    private String subject;

    public Course(String name, int number, int numStudents, int semester, int creditHours, String subject) {
        this.name = name;
        this.number = number;
        this.numStudents = numStudents;
        this.semester = semester;
        this.creditHours = creditHours;
        this.subject = subject;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumStudents() {
        return numStudents;
    }

    public void setNumStudents(int numStudents) {
        this.numStudents = numStudents;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        this.creditHours = creditHours;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
