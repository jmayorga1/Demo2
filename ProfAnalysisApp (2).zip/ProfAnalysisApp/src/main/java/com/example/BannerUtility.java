package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class BannerUtility {

    private static WebDriver driver = new ChromeDriver();

    static {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
    }

    public static List<Course> getProfCourses(String name, String semester) {
        driver.get("https://banner.ggc.edu");
        //here click on courses schedule link
        WebElement coursesLink = driver.findElement(By.xpath("/html/body/div[3]/div/table/tbody/tr/td/span/p[3]/a"));
        coursesLink.click();

        Select semesterDropDown = new Select(driver.findElement(By.xpath("/html/body/div[3]/form/table/tbody/tr/td/select")));
       //go thru index until finding right semester
        int i = 1;
        while (true){
              semesterDropDown.selectByIndex(i);
              String currentSemester = semesterDropDown.getFirstSelectedOption().getText();
              if(currentSemester.contains(semester)){
                  System.out.println(currentSemester);
                  break;
              }
              i++;
        }
        WebElement submitButton = driver.findElement(By.xpath("/html/body/div[3]/form/input[2]"));
        submitButton.click();

        Select subjectDropDown = new Select(driver.findElement(By.xpath("//*[@id=\"subj_id\"]")));
        subjectDropDown.selectByValue("ITEC");

        WebElement classSearchButton = driver.findElement(By.xpath("/html/body/div[3]/form/input[12]"));
        classSearchButton.click();

        WebElement courseTable = driver.findElement(By.xpath("/html/body/div[3]/table[1]"));
        List<WebElement> coursesRows = courseTable.findElements(By.xpath("/html/body/div[3]/table[1]/tbody/tr"));//its in the table fot every table there are 2 trs
        for (int j = 0; j < coursesRows.size(); j+=2) {

            WebElement heading = coursesRows.get(j);
            WebElement body = coursesRows.get(j+1);
            //Course course = getCourseFromWebElement(heading, body,semester);

            ///
            WebElement courseLink = heading.findElement(By.tagName("a"));
            String courseUrl = courseLink.getAttribute("href");
            String courseHeading = courseLink.getText();
            if(!courseHeading.contains("-")){
                // somethings wrong
                return null;

            }
            String courseName = courseHeading.substring(0,courseHeading.indexOf("-")).trim();
            String [] tokens = courseHeading.split("-");
            String courseString = tokens[tokens.length-2];
            String subject = courseString.split(" ")[0];
            String courseNumber = courseString.split(" ")[1];
            courseLink.click();
            String numberOfStudents = driver.findElement(By.xpath("/html/body/div[3]/table[1]/tbody/tr[2]/td/table/tbody/tr[2]/td[2]")).getText();
            //driver.navigate().back();
            WebElement goBackToCourses = driver.findElement(By.xpath("/html/body/div[3]/table[2]/tbody/tr/td/a"));
            goBackToCourses.click();
            System.out.println(courseName + " " + courseString + " " + numberOfStudents);


        }
        System.out.println(coursesRows.size());
        return null;

    }

    private static Course getCourseFromWebElement(WebElement heading, WebElement body,String semester) {
        WebElement courseLink = heading.findElement(By.tagName("a"));
        String courseUrl = courseLink.getAttribute("href");
        String courseHeading = courseLink.getText();
        if(!courseHeading.contains("-")){
            // somethings wrong
            return null;

        }
        String courseName = courseHeading.substring(0,courseHeading.indexOf("-")).trim();
        String [] tokens = courseHeading.split("-");
        String courseString = tokens[tokens.length-2];
        String subject = courseString.split(" ")[0];
        String courseNumber = courseString.split(" ")[1];
        courseLink.click();
        String numberOfStudents = driver.findElement(By.xpath("/html/body/div[3]/table[1]/tbody/tr[2]/td/table/tbody/tr[2]/td[2]")).getText();
        //driver.navigate().back();
        WebElement goBackToCourses = driver.findElement(By.xpath("/html/body/div[3]/table[2]/tbody/tr/td/a"));
        goBackToCourses.click();
        System.out.println(courseName + " " + courseString + " " + numberOfStudents);
        return null;
    }
}
